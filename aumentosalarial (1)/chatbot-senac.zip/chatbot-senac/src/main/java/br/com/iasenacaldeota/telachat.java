package br.com.iasenacaldeota;

import java.awt.Desktop;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.awt.event.ActionEvent;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.PDFont;


public class telachat {

	private JFrame frame;
	String resposta;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					telachat window = new telachat();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public telachat() {
		initialize();
	}
	private void salvarPDF(File arquivo, String texto) { 
		try (PDDocument document = new PDDocument()) { 
			PDPage page = new PDPage(); document.addPage(page); 
			PDFont font = PDType1Font.HELVETICA; float fontSize = 12; 
			float leading = 14.5f; float margin = 50; 
			float widthMax = page.getMediaBox().getWidth() - 2 * margin; 
			float startY = page.getMediaBox().getHeight() - margin; 
			float yPosition = startY; 
			PDPageContentStream content = new PDPageContentStream(document, page); 
			content.beginText(); content.setFont(font, fontSize); 
			content.setLeading(leading); content.newLineAtOffset(margin, yPosition); 
			String[] linhas = texto.split("\n"); for (String linha : linhas) { 
				String[] palavras = linha.split(" "); 
				StringBuilder buffer = new StringBuilder(); 
				for (String palavra : palavras) { 
					String testLine = buffer + palavra + " "; 
					float size = font.getStringWidth(testLine) / 1000 * fontSize; 
					if (size > widthMax) { 
						content.showText(buffer.toString()); 
					content.newLine(); 
					yPosition -= leading; 
					if (yPosition <= margin) { 
						content.endText(); 
					content.close(); 
					page = new PDPage(); 
					document.addPage(page); 
					content = new PDPageContentStream(document, page); 
					content.beginText(); content.setFont(font, fontSize); 
					content.setLeading(leading); yPosition = startY; 
					content.newLineAtOffset(margin, yPosition); 
					} 
					buffer = new StringBuilder(palavra + " "); 
					} 
					else { 
						buffer.append(palavra).append(" "); 
						} 
					} 
				content.showText(buffer.toString()); 
				content.newLine(); yPosition -= leading; 
				if (yPosition <= margin) { content.endText(); 
				content.close(); page = new PDPage(); 
				document.addPage(page); 
				content = new PDPageContentStream(document, page); 
				content.beginText(); content.setFont(font, fontSize); 
				content.setLeading(leading); yPosition = startY; 
				content.newLineAtOffset(margin, yPosition); 
				} 
				} 
			content.endText(); 
			content.close(); 
			document.save(arquivo); 
			JOptionPane.showMessageDialog(null, "PDF salvo com sucesso!\n" + arquivo.getAbsolutePath()); 
			} catch (IOException e) { 
				JOptionPane.showMessageDialog(null, "Erro ao gerar PDF: " + e.getMessage()); 
				} 
		}






	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 526, 589);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		
		JTextPane txtchat = new JTextPane();
		txtchat.setEditable(false);
		txtchat.setBounds(10, 11, 414, 443);
		frame.getContentPane().add(txtchat);
		
		JScrollPane scrollPane = new JScrollPane(txtchat);
		scrollPane.setBounds(10, 11, 414, 440);
		frame.getContentPane().add(scrollPane);
		
		JTextArea txtarea = new JTextArea();
		txtarea.setBounds(10, 462, 351, 77);
		frame.getContentPane().add(txtarea);
		
		JButton btnenviar = new JButton("");
		btnenviar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
				String pergunta = txtarea.getText();
				ia intel = new ia();
				resposta = intel.mensagem(pergunta);
				txtchat.setText(resposta);
				txtarea.setText("");
				}catch(Exception e) {
					System.out.println("erro");
				}
			}
		});
		btnenviar.setIcon(new ImageIcon("C:\\Users\\Aluno\\Downloads\\9195557 (1).png"));
		btnenviar.setBounds(369, 465, 55, 74);
		frame.getContentPane().add(btnenviar);
		
		JButton btnwhatss = new JButton("");
		btnwhatss.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String numero = JOptionPane.showInputDialog(null,"Digite o telefone que deseja enviar","Telefone",JOptionPane.INFORMATION_MESSAGE);
					String texto = URLEncoder.encode(resposta,"UTF-8");
					String link = "https://wa.me/"+numero+"?text="+texto;
					Desktop.getDesktop().browse(new URI(link));
				}catch(Exception e) {
					JOptionPane.showMessageDialog(null, e.getMessage(),"erro",-1);
				}
			}
		});
		btnwhatss.setIcon(new ImageIcon("C:\\Users\\Aluno\\Downloads\\logo_whatsapp_icon_181638 (1).png"));
		btnwhatss.setBounds(444, 11, 55, 48);
		frame.getContentPane().add(btnwhatss);
		
		JButton btnemail = new JButton("");
		btnemail.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String email = JOptionPane.showInputDialog(null,"Informe o email",
							"Email",JOptionPane.INFORMATION_MESSAGE);
					String assunto = "Resposta do chat";
					email tel = new email();
					tel.enviar(email, assunto, resposta);
				}catch(Exception ae) {
					JOptionPane.showMessageDialog(null,ae.getMessage(),"Aviso",-1);
				}
			}
		});
		btnemail.setIcon(new ImageIcon("C:\\Users\\Aluno\\Downloads\\2989993 (1).png"));
		btnemail.setBounds(444, 70, 55, 48);
		frame.getContentPane().add(btnemail);
		
		JButton btnbaixar = new JButton("");
		btnbaixar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser fileChooser = new JFileChooser(); 
				fileChooser.setDialogTitle("Salvar PDF"); 
				int opcao = fileChooser.showSaveDialog(null); 
				if (opcao == JFileChooser.APPROVE_OPTION) { 
					File arquivo = fileChooser.getSelectedFile(); 
					
					if (!arquivo.getName().toLowerCase().endsWith(".pdf")) { 
						arquivo = new File(arquivo.getAbsolutePath() + ".pdf"); 
					}
					salvarPDF(arquivo, resposta);
				}
			}
		});
		btnbaixar.setIcon(new ImageIcon("C:\\Users\\Aluno\\Downloads\\724933 (1).png"));
		btnbaixar.setBounds(444, 129, 55, 48);
		frame.getContentPane().add(btnbaixar);
	}
}
