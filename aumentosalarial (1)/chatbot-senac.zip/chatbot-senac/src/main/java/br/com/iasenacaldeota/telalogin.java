package br.com.iasenacaldeota;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JCheckBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;

public class telalogin {

	private JFrame frame;
	private JTextField txtlogin;
	private JPasswordField txtsenha;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					telalogin window = new telalogin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public telalogin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Login");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(22, 41, 68, 29);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Senha");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(22, 81, 68, 38);
		frame.getContentPane().add(lblNewLabel_1);
		
		txtlogin = new JTextField();
		txtlogin.setBounds(88, 49, 223, 20);
		frame.getContentPane().add(txtlogin);
		txtlogin.setColumns(10);
		
		txtsenha = new JPasswordField();
		txtsenha.setBounds(88, 94, 223, 20);
		frame.getContentPane().add(txtsenha);
		
		JCheckBox checksenha = new JCheckBox("Mostrar Senha");
		checksenha.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(checksenha.isSelected()) {
					txtsenha.setEchoChar((char)0);
				}else {
					txtsenha.setEchoChar('*');
				}
			}
		});
		checksenha.setBounds(19, 121, 97, 23);
		frame.getContentPane().add(checksenha);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String user = txtlogin.getText();
				String senha =txtsenha.getText();
				BancoDeDados banc = new BancoDeDados();
				banc.conectar();
				if(banc.estaConectado()) {
					if(banc.validarusuario(user,senha)) {
						JOptionPane.showMessageDialog(null, "entrada liberada"
								,"aviso",-1);
					}else {
						JOptionPane.showMessageDialog(null, "usuario ou senha inválida"
								,"aviso",-1);
					}
				}
			}
		});
		btnLogin.setBounds(171, 191, 89, 23);
		frame.getContentPane().add(btnLogin);
	}
}
