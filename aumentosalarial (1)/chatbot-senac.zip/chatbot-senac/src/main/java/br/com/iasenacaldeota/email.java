package br.com.iasenacaldeota;

import jakarta.mail.*;
import jakarta.mail.internet.*;
import java.util.Properties;

public class email {

    public void enviar(String email,String assunto,String texto){
        
        final String usuario = "napnemaracanau@gmail.com";
        final String senha = "yjzk ogiz rrjv ugfe";

        
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        
        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(usuario, senha);
            }
        });

        try {
  
            Message mensagem = new MimeMessage(session);
            mensagem.setFrom(new InternetAddress(usuario));
            mensagem.setRecipients(Message.RecipientType.TO,
                    InternetAddress.parse(email));
            mensagem.setSubject(assunto);
            mensagem.setText(texto);

            
            Transport.send(mensagem);
            System.out.println("Email sent successfully!");

        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
}
