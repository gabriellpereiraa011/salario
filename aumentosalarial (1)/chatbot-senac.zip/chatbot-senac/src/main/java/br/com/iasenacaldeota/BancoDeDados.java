package br.com.iasenacaldeota;
import java.sql.Connection;//gerencia a conexão
import java.sql.DriverManager;// gerencia o driver
import java.sql.ResultSet; //Armazena as consultas no banco com o select;
import java.sql.Statement; //gerencia as consultas

public class BancoDeDados {
	private Connection connection = null; //cria uma variável como vazia
	private Statement statement = null;//cria uma variável como vazia
	private ResultSet resultset = null;//cria uma variável como vazia
	public void conectar() {
		String servidor = "jdbc:mysql://localhost:3306/credencial";
		String usuario = "root";
		String senha = "Aluno";
		String driver = "com.mysql.cj.jdbc.Driver";
		try {
			Class.forName(driver);
			this.connection = DriverManager.getConnection(servidor,usuario,senha);
			this.statement = this.connection.createStatement();
		}catch(Exception e){
			System.out.println("Error"+e.getMessage());
		}
	}
	public boolean estaConectado() {
		if(this.connection!=null) {
			return true;
		}else {
			return false;
		}
	}
	public void inserirContato(String nome, String telefone) {
		try {
			String query="insert into contato(nome,telefone) values ('"+nome+"','"+telefone+"')";
			this.statement.executeUpdate(query);
		}catch(Exception e) {
			System.out.println("Error: "+e.getMessage());
		}
	}
	public void listarContato() {
		try {
		String query = "select * from contato order by nome";
		this.resultset= this.statement.executeQuery(query);
		while(this.resultset.next()) {
			System.out.println("ID: "+ this.resultset.getString("id")+" Nome: "
		+this.resultset.getString("nome")+" Telefone: "+ this.resultset.getString("telefone"));
		}
		}catch(Exception e) {
			System.out.println("Erro"+ e.getMessage());
		}
		
	}
	public void editarContato(String id,String nome,String telefone) {
		try {
		String query= "update contato set nome= '"+nome+"',telefone='"+telefone+"' where id ="+id+"";
		this.statement.executeUpdate(query);
		}catch(Exception e) {
			System.out.println("Erro: "+e.getMessage());
		}
	}
	public void apagarContato(String id) {
		try {
			String query = "delete from contato where id = '"+id+"'";
			this.statement.executeUpdate(query);
		}catch(Exception e) {
			System.out.println("Erro: "+e.getMessage());
		}
	}
	public void desconectar() {
		try {
			this.connection.close();
		}catch(Exception e) {
			System.out.println("Erro"+e.getMessage());
		}
	}
	public boolean validarusuario(String usuario, String senha) {
		try {
			String query = "select * from login where usuario = '"+usuario+"'and senha = '"+senha+"'";
			this.resultset= this.statement.executeQuery(query);
			while(this.resultset.next()) {
				return true;
			}
			}catch(Exception e) {
				System.out.println("Erro"+ e.getMessage());
			}
		return false;
	}
}
